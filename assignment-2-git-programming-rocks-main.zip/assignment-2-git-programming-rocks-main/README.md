[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/k80Fz6lw)
# Assignment 2, Git and GitHub

This repository contains week 2 assignment for the course *Software Engineering Techniques*. For the assignment description, go to [ASSIGNMENT.md](ASSIGNMENT.md).