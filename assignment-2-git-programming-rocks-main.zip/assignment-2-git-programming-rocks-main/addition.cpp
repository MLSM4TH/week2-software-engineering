#include "addition.h"

complex addition::execute(complex a, complex b) const {
    return a + b;
}
